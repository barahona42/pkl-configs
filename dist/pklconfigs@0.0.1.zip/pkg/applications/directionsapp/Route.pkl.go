// Code generated from Pkl module `barahona42.configs.pkg.applications.DirectionsApp`. DO NOT EDIT.
package directionsapp

type Route struct {
	Origin string `pkl:"Origin"`

	Destination string `pkl:"Destination"`

	Label string `pkl:"Label"`
}
