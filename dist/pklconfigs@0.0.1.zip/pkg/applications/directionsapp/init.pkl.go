// Code generated from Pkl module `barahona42.configs.pkg.applications.DirectionsApp`. DO NOT EDIT.
package directionsapp

import "github.com/apple/pkl-go/pkl"

func init() {
	pkl.RegisterMapping("barahona42.configs.pkg.applications.DirectionsApp", DirectionsApp{})
	pkl.RegisterMapping("barahona42.configs.pkg.applications.DirectionsApp#Directions", Directions{})
	pkl.RegisterMapping("barahona42.configs.pkg.applications.DirectionsApp#Route", Route{})
}
