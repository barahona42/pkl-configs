// Code generated from Pkl module `barahona42.pklconfigs.pkg.applications.Core`. DO NOT EDIT.
package core

type Application struct {
	Name string `pkl:"Name"`

	Description string `pkl:"Description"`
}
