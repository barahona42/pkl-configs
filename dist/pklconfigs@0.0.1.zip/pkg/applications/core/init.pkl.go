// Code generated from Pkl module `barahona42.pklconfigs.pkg.applications.Core`. DO NOT EDIT.
package core

import "github.com/apple/pkl-go/pkl"

func init() {
	pkl.RegisterMapping("barahona42.pklconfigs.pkg.applications.Core#Application", Application{})
	pkl.RegisterMapping("barahona42.pklconfigs.pkg.applications.Core", Core{})
}
